import rpyc
import sys

cmd = int(sys.argv[1])

conn = rpyc.connect("192.168.1.48", 12345)

switch = [0,0,0,0]

if cmd == 5:
    conn.root.auto()
else:
    switch[int(cmd-1)] = 1
    conn.root.manual(switch[0],switch[1],switch[2],switch[3])
