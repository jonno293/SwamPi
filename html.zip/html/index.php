<?php
    if (isset($_POST['ToggleFanHi'])) 
    {
		
         echo exec('python3 swampi_remote.py 1');
    }
    if (isset($_POST['ToggleFanLo'])) 
    {
		
         exec('python3 swampi_remote.py 2');
    }
    if (isset($_POST['TogglePump'])) 
    {
		
         exec('python3 swampi_remote.py 4');
    }
    if (isset($_POST['TogglePurgePump'])) 
    {
         exec('python3 swampi_remote.py 3');
    }
    if (isset($_POST['NestControl'])) 
    {
         exec('python3 swampi_remote.py 5');
    }
?>
<style>
form{
text-align: center;
width: 100%;
font-size: 1em;
}
button {
width: 100%;
  background-color: #04AA6D;
  border: none;
  color: white;
  padding: 16px 32px;
  text-decoration: none;
  margin: 4px 2px;
  cursor: pointer;
  font-size: 1em
}
body{
text-align: center;
font-size: 4em;
}
</style>
<html> 
<body>
<head>
<title> Swamp Cooler Override </title>
Swamp Cooler Override <p>
</head>


    <form method="post" >       
		
		<button name="ToggleFanHi">Toggle Fan Hi</button> 
		<button name="ToggleFanLo">Toggle Fan Lo</button>
		<button name="TogglePump">Toggle Pump</button> 
		<button name="TogglePurgePump">Toggle Purge Pump</button>
		<button name="NestControl">Allow Nest Control</button>
        
    </form>
    
</body>


